#!/usr/bin/python3
radius = 10
counter = 9
while counter >= 0:
	if radius > 7:
		print("Big radius")
	elif radius > 3:
		print("Medium radius")
	else
		print("Small radius")
	
	counter = counter - 1
	radius = radius - 2*counter

