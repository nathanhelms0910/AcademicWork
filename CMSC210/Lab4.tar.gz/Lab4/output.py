#!/usr/bin/python3
import math
print(5)
print("Hello" + "World")

radius = 5
print("Radius: " + str(radius) + "Circumference: " + str(radius*math.pi))
print(radius / 2)
print(radius / 2.0)

