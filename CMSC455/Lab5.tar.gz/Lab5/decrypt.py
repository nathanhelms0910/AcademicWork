import math

def multiply(num, d, N):
	"""Compute num ^ d mod N"""
	if num >= N:
		print("Too large")
		return 0
	value = 1

	#This could be done much more efficiently with square-and-multiply, but brute force is easier to code
	for t in range(d):
		value = (value * num) % N
	return value

def decrypt(num, d, N):
	"""Given a number 'num', decrypt it and then convert it to a string"""
	m = multiply(num, d, N)

	#convert to a string
	str = ""
	while m > 0:
		b = m % 256
		str = chr(b) + str
		m = int(m / 256)
	return str

#Read a decryption key from the terminal, then use it to decrypt our message
print("Please type the decryption exponent:")
d = int(input())
print("Please type the decryption modulus:")
N = int(input())
print("Please type your message:")
m = int(input())
m = decrypt(m, d, N)
print(m)
