Nathan Helms
Lab 2: Spurious Keys
CMSC455

I attempted to convert the shift cipher implementation to use the affine cipher for encryption, but I could not figure it out fully in the end. my attempt can be found in glitter.cpp
