#include <iostream>

using namespace std;

int main()
{
  cout << "never gonna give you up!";
  cin.get();
  cout << "never gonna let you down!";
  cin.get();
  cout << "never gonna run around and desert you!";
  cin.get();
  cout << "never gonna make you cry!";
  cin.get();
  cout << "never gonna say goodbye!";
  cin.get();
  cout << "never gonna tell a lie and hurt you!";
  cin.get();
  return 0;
}

//I am not sorry Dr Marmorstein. you were the one that gave us this freedom
// :)

